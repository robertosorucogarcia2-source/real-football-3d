# REAL FOOTBALL 3D — Starter Prototype

Starter kit for a Unity 3D Android football prototype. This is source code and setup guidance, not a compiled APK or a complete commercial game.

## Target
- Unity 2022.3 LTS or newer
- Android Build Support (SDK, NDK and OpenJDK through Unity Hub)
- Landscape orientation
- First exhibition match: Real Madrid vs Barcelona

## Included scripts
- `MobileJoystick.cs`: virtual joystick input component.
- `FootballPlayerController.cs`: player movement, sprint and kick actions.
- `FootballBall.cs`: simple ball impulse and ground friction.
- `FollowCamera.cs`: smooth third-person follow camera.
- `MatchManager.cs`: match clock and score UI hooks.

## Quick scene setup
1. Create a new **3D Core** Unity project.
2. Set **File > Build Settings > Android > Switch Platform**.
3. In **Player Settings**, set Default Orientation to **Landscape Left**.
4. Create a pitch using a Plane (scale approximately X=5, Z=8), add white field markings, two goals, lighting and a stadium environment.
5. Add a Capsule with a `CharacterController` for the controlled footballer. Add `FootballPlayerController`.
6. Create a Sphere for the ball, add a Rigidbody and Sphere Collider, then add `FootballBall`.
7. Create a Canvas (Screen Space - Overlay). Add a joystick background and handle; attach `MobileJoystick` to the joystick root and assign the handle.
8. Add UI Buttons for **Sprint**, **Pass**, and **Shoot**. Connect their Pointer Down/Up events to the corresponding methods on `FootballPlayerController` as described below.
9. Add a Camera and `FollowCamera`; assign the player transform.
10. Add a Canvas text label (legacy UI Text) for the clock and two score labels; assign them to `MatchManager`.

## UI button wiring
- Sprint button: EventTrigger Pointer Down -> `SetSprint(true)`; Pointer Up -> `SetSprint(false)`.
- Pass button: OnClick -> `Pass()`.
- Shoot button: OnClick -> `Shoot()`.
- The joystick root must have `MobileJoystick`; assign its handle RectTransform.

## Team look
For a first visual pass, use white shirts/shorts for Real Madrid and blue-and-red shirts with dark shorts for Barcelona. Use original placeholder assets or properly licensed assets. Club names and crests are trademarks; this prototype is unaffiliated.

## Important scope
This is a playable foundation for movement and ball interaction once assembled in Unity. It does not yet include full 22-player AI, licensed player likenesses, online multiplayer, commentary, advanced animation, or production-ready stadium assets. Those are later development milestones.
