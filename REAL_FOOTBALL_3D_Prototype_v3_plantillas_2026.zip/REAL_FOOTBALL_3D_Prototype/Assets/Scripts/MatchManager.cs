using UnityEngine;
using UnityEngine.UI;

public class MatchManager : MonoBehaviour
{
    [Header("Match settings")]
    [SerializeField] private float matchLengthSeconds = 300f; // Five real minutes
    [SerializeField] private Text clockText;
    [SerializeField] private Text homeScoreText;
    [SerializeField] private Text awayScoreText;

    public int HomeScore { get; private set; }
    public int AwayScore { get; private set; }
    public bool IsFinished { get; private set; }
    private float elapsed;

    private void Start() => RefreshUI();

    private void Update()
    {
        if (IsFinished) return;

        elapsed += Time.deltaTime;
        if (elapsed >= matchLengthSeconds)
        {
            elapsed = matchLengthSeconds;
            IsFinished = true;
        }
        RefreshClock();
    }

    public void AddHomeGoal()
    {
        if (IsFinished) return;
        HomeScore++;
        RefreshUI();
    }

    public void AddAwayGoal()
    {
        if (IsFinished) return;
        AwayScore++;
        RefreshUI();
    }

    public void RestartMatch()
    {
        elapsed = 0f;
        HomeScore = 0;
        AwayScore = 0;
        IsFinished = false;
        RefreshUI();
    }

    private void RefreshUI()
    {
        if (homeScoreText != null) homeScoreText.text = HomeScore.ToString();
        if (awayScoreText != null) awayScoreText.text = AwayScore.ToString();
        RefreshClock();
    }

    private void RefreshClock()
    {
        if (clockText == null) return;
        int displayedSeconds = Mathf.FloorToInt((elapsed / matchLengthSeconds) * 90f * 60f);
        displayedSeconds = Mathf.Min(displayedSeconds, 90 * 60);
        clockText.text = $"{displayedSeconds / 60:00}:{displayedSeconds % 60:00}";
    }
}
