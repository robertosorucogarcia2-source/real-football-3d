# REAL FOOTBALL 3D — Android prototype starter

Unity starter kit for a football game prototype. The package contains C# scripts and setup instructions; it is **not a compiled APK** and does not yet contain finished 3D player/stadium assets.

## Current design
- Android, landscape orientation
- 3D realistic football-game presentation
- First exhibition fixture: Real Madrid vs Barcelona
- Five real minutes per match (clock displayed from 00:00 to 90:00)
- Planned modes: Exhibition, Tournament and Career

## Included scripts
- `MobileJoystick.cs` — touch joystick input
- `FootballPlayerController.cs` — player movement, sprint, pass and shoot
- `FootballBall.cs` — ball impulse and ground friction
- `FollowCamera.cs` — smooth follow camera
- `MatchManager.cs` — five-minute match clock and score
- `GameModeManager.cs` — mode selection and default teams

## Unity setup
1. Create a Unity 3D Core project (Unity 2022.3 LTS or newer).
2. Install Android Build Support, Android SDK & NDK Tools, and OpenJDK through Unity Hub.
3. In Build Settings, switch platform to Android.
4. Set Player Settings > Resolution and Presentation > Default Orientation to Landscape.
5. Create a pitch, goals, lighting and player placeholders.
6. Add a CharacterController and `FootballPlayerController` to the controlled player.
7. Add a Rigidbody and SphereCollider to the ball, then attach `FootballBall`.
8. Create a Canvas with joystick, buttons, score labels and clock. Connect the references in the Inspector.
9. Add `MatchManager` and `GameModeManager` to scene objects and wire menu buttons to the public methods.
10. Build and test on a physical Android device.

## Button connections
- Sprint: Pointer Down -> `SetSprint(true)`; Pointer Up -> `SetSprint(false)`.
- Pass: OnClick -> `Pass()`.
- Shoot: OnClick -> `Shoot()`.
- Mode buttons: OnClick -> `SelectExhibition()`, `SelectTournament()` or `SelectCareer()`.
- Play button: OnClick -> `StartSelectedMode()`.

## Development status
This is a foundation for assembling a playable prototype in Unity. Full 22-player AI, goalkeeper behavior, refereeing, fouls, tournament brackets, career progression, polished animations, licensed club/player assets, sound and production optimization still need implementation.

Use original or properly licensed assets. Club names and crests are trademarks; this is an independent, unaffiliated prototype.


## v3 — Plantillas 2026/27 integradas

Se añadieron `Assets/StreamingAssets/team_rosters_2026_27.json`, `RosterDatabase.cs` y `LineupManager.cs`. El archivo contiene nombres, dorsales, posiciones y una alineación inicial sugerida para Real Madrid y FC Barcelona, más suplentes.

### Configuración en Unity
1. Añade un GameObject `RosterDatabase` y el componente `RosterDatabase`.
2. En un Canvas crea un Scroll View y usa su objeto `Content` como `List Root`.
3. Crea un prefab UI Text para las filas y asígnalo a `Row Prefab`.
4. Añade `LineupManager` a la pantalla de alineaciones y asigna Database, List Root, Row Prefab, Team Title y Formation Label.
5. Conecta botones de equipo a `ShowRealMadrid()` y `ShowBarcelona()`.

**Alcance:** esta integración carga y muestra datos de plantillas; no crea automáticamente modelos 3D, caras, animaciones ni IA de jugadores. Los titulares son sugerencias para el prototipo, no alineaciones oficiales de un partido. Plantillas y dorsales deben revisarse antes de publicar. El proyecto sigue siendo código fuente inicial, no un APK terminado.

Fuentes: Real Madrid (https://www.realmadrid.com/en-US/football/first-team/players), dorsales Real Madrid 2026/27 (https://www.realmadrid.com/en-US/news/football/first-team/latest-news/dorsales-del-real-madrid-para-la-temporada-2026-27-10-08-2026), FC Barcelona (https://www.fcbarcelona.com/en/football/first-team/squad), dorsales Barça 2026/27 (https://www.fcbarcelona.com/en/news/4570894/202627-first-team-jersey-numbers-confirmed).
